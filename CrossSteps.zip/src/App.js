import logo from './logo.svg';
import './App.css';

import Form from './Componets/Form';

function App() {
  return (
    <>
    <section className="hero is-light has-text-centered">
      <div className="hero-body">
      
      </div>
    </section>
    <div className="container pt-5"   >
      <div className="columns">
        <div className="column is-half is-offset-one-quarter" >
          <Form  />
        </div>
      </div>
    </div>
  </>
  );
}

export default App;
