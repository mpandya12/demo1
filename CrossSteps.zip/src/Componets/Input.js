import React from 'react';
import PropTypes from 'prop-types';
import "./input.css"
import { Form } from 'react-bootstrap';
const Input = ({ type = 'text', placeholder, name, value, onChange, error }) => {
  return(
    <div className="inputbox" >

      <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
        <Form.Label style={{marginLeft:"100px",fontSize:"20px"}}>{name}</Form.Label>
        <input  className={error ? "input is-danger" : "input"} 
        type={type} 
        placeholder={placeholder}
        name={name}
        value={value}
        onChange={onChange}
        autoComplete="off"
           style={{marginLeft:"20px"}} />
      </Form.Group>
      {error && <div className="has-text-danger-dark">{error}</div>}
    </div>
  );
}

Input.propTypes = {
  type: PropTypes.string,
  placeholder: PropTypes.string,
  name: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object
  ]),
  onChange: PropTypes.func.isRequired
}

export default Input;
//give me css for this page for nice ui

