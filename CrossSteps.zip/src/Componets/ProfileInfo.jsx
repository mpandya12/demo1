import React from 'react'
import Step from './Step'

function ProfileInfo({step,value,palceholder}) {
    const[data,setdata]=[{
        step1:{
            name:{value},
            palceholder:{palceholder},
            data:{value}
        },
        step2:{
            name:{value},
            palceholder:{palceholder},
            data:{value}
        },
        step3:{
            name:{value},
            palceholder:{palceholder},
            data:{value}
        },
        step4:{
            name:{value},
            palceholder:{palceholder},
            data:{value}
        }
    }]
  return (
    <>
    <div>ProfileInfo</div>
      <div>
        <h1>Manushi</h1>
        <h2>Dipen</h2>
        <h3>Jay</h3>
        <h4>Chitan</h4>
        <h5>heet</h5>
        {/* {<Step name="lname" lname="pandya" fname="manushi"/>}
       {<Step name="fname" lname="shah" palceholder="enter your first name" />}
       {<Step name="surname" palceholder="enter your name"/>}
       {<Step name="pincode" palceholder="enter your area pincode "/>}
       {<Step />} */}

      </div>
    <div>

    </div>
    </>
  
    
  )
}

export default ProfileInfo