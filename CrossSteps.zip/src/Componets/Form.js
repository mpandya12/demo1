import React, { useState } from 'react';

import Step from './Step';
import Preview from './Preview';
import validate from '../validate';
import Swal from 'sweetalert2';

const Form = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    stepOne: {
      
      firstName: {
        value: '',
        required: true,
        type: 'input',
        placeholder: 'First name'
      },
      lastName: {
        value: '',
        required: true,
        type: 'input',
        placeholder: 'Last name'
      },
      email: {
        value: '',
        email: true,
        type: 'input',
        placeholder: 'Email'
      },
      password: {
        value: '',
        minLength: 6,
        type: 'input:password',
        placeholder: 'Password'
      }
    },
    stepTwo: {
      
      street:{
        value: '',
        required: true,
        type: 'input',
        placeholder: 'street name'
      },
      city:{
        value: '',
        required: true,
        type: 'input',
        placeholder: 'city name'
      },
      state:{
        value: '',
        required: true,
        type: 'input',
        placeholder: 'state name'
      },
      pincode:{
        value: '',
        required: true,
        type: 'input',
        placeholder: 'pincode name'
      }
    },
    stepThree:{
      phone:{
        value:"",
        phone:true,
        type:'input',
        placeholder:"phone"
      },
      linkdin:{
        value:'',
        linkdin:true,
        type:'input',
        placeholder:'linkdin',
        
      },
      github:{
        value:'',
        github:true,
        type:'input',
        placeholder:'github'
      }
    },
    stepFlour:{
      bday:{
        value:'',
        bday:true,
        type:'input',
        placeholder:'bday'
      }
      
    
    }
    
  });
  const [errors, setErrors] = useState({});

  const changeHandler = (step, e) => {
    e.persist();

    setFormData(prev => ({
      ...prev,
      [step]: {
        ...prev[step],
        [e.target.name]: {
          ...prev[step][e.target.name],
          value: e.target.value
        }
      }
    }));
  }

  

  const stepChangeHandler = (values, e) => {
    e.preventDefault();
    const newErrors = validate(values);
    setErrors(newErrors);
    if(Object.keys(newErrors).length === 0) {
      setStep(step + 1);
    }
  }

  const submitHandler = (e) => {
    e.preventDefault();

   //  alert("form submitted",formData.stepOne)
     Swal.fire({
      icon: "success",
      title: "Submitted",
  
 
   });
     console.log("stepOne",formData.stepOne)
     console.log("StepTwo",formData.stepTwo);
     console.log("StepThree",formData.stepThree);
     console.log("StepFlour",formData.stepFlour);


  }

  return(
    <form onSubmit={submitHandler} style={{border:"2px solid black",borderRadius:"4px"}}>
      <h1 className="is-size-2 has-text-centered mb-4" style={{textAlign:"center"}}>Personal Informaction</h1>
      {step === 1 && <Step 
    
        data={formData.stepOne}
        onChange={changeHandler}
        onStepChange={stepChangeHandler}
        errors={errors}
        stepKey="stepOne"
        step={1}
      />}
      {
      step === 2 && <Step 
        data={formData.stepTwo}
        onChange={changeHandler}
        onStepChange={stepChangeHandler}
        errors={errors}
        stepKey="stepTwo"
        onPrevStep={(step) => setStep(step)}
        step={2}
      />}
      {
        
        step === 3 && <Step 
        data={formData.stepThree}
        onChange={changeHandler}
        onStepChange={stepChangeHandler}
        errors={errors}
        stepKey="stepThree"
        onPrevStep={(step) => setStep(step)}
        step={3}/>
      }
      {
        step===4 && <Step
        data={formData.stepFlour}
        onChange={changeHandler}
        onStepChange={stepChangeHandler}
        errors={errors}
        stepKey="stepFlour"
        onPrevStep={(step) => setStep(step)}
        step={4}
        />
      }
      {step === 5 && <Preview 
        onPrevStep={() => setStep(step - 1)}
        data={[
          {label: 'First name', value: formData.stepOne.firstName.value },
          {label: 'Last name', value: formData.stepOne.lastName.value },
          {label: 'Email', value: formData.stepOne.email.value },
          {label: 'Password', value: formData.stepOne.password.value },
          {label:"street",value:formData.stepTwo.street.value},
          {label:"city",value:formData.stepTwo.city.value},
          {label:"state:",value:formData.stepTwo.state.value},
          {label:"pincode",value:formData.stepTwo.pincode.value},
          {label:'linkdin',value:formData.stepThree.linkdin.value},
          {label:'phone',value:formData.stepThree.phone.value},
          {label:'github',value:formData.stepThree.github.value},
          {label:'bday',value:formData.stepFlour.bday.value}
        ]
       
      }
       
      />}
    
    </form>
  );
}

export default Form;

//in this form when go to next form that time my data is bind but when i fille the second step that go to perious step that time data is not refrence 