import React, { Fragment } from 'react';
import { Button } from 'react-bootstrap';

const Preview = ({ data, onPrevStep }) => {
  return(
    <div className="panel is-primary" >
      <p className="panel-heading" style={{textAlign:"center",fontSize:"30px"}}>Your data</p>
      <div className="panel-block is-block">
        <ul className="py-5">
          {data.map((input, index) => (
            <li key={index} className="py-2">
              <strong>{input.label}</strong>{input.value}
            
            </li>
          ))}
        </ul>
        <div style={{marginLeft:"170px"}}>
          <Button  variant='success'type="button" className="button is-warning mr-2" onClick={onPrevStep}>back</Button>
          <Button type="submit" className="button is-primary">Submit form</Button>
        </div>
      </div>
    </div>
  );
}

export default Preview;