import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import Button from 'react-bootstrap/Button';

import Input from './Input';
import Select from './Select';



const Step = ({ data, onChange, onFileChange, onStepChange, errors, stepKey, step, onPrevStep }) => {
  let output = [];

  for(const [key, val] of Object.entries(data)) {
    if(val.type.split(':')[0] === 'input') {
      output.push(<Input 
        key={key}
        placeholder={val.placeholder}
        name={key}
        value={val.value}
        onChange={(e) => onChange(stepKey, e)}
        error={errors[key]}
        type={val.type.split(':')[1]}
      
      />);
    }
  }
  
  return(
    <>
      {output}
      {step > 1 && <Button variant='success' type="button" className="button is-warning mr-2" onClick={() => onPrevStep(step - 1)} style={{height:"50px",width:"80px",marginLeft:"170px"}}>back</Button>}
      
      <Button type="button" className="button is-link" style={{height:"50px",width:"80px"}} onClick={(e) => onStepChange(data, e)}>Next</Button>
    </>
  );
}

Step.propTypes = {
  data: PropTypes.object.isRequired,
  onChange: PropTypes.func.isRequired,
  onFileChange: PropTypes.func,
  onStepChange: PropTypes.func.isRequired,
  errors: PropTypes.object,
  stepKey: PropTypes.string.isRequired,
  step: PropTypes.number.isRequired,
  onPrevStep: PropTypes.func
}

export default Step;