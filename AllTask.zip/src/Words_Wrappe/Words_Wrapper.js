import React from 'react'

function Words_Wrapper() {
  return (
    <div>Words_Wrapper</div>
  )
}

export default Words_Wrapper