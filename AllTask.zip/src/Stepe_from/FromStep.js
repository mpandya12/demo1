import React from 'react'

function FromStep() {
  return (
    <div>FromStep</div>
  )
}

export default FromStep