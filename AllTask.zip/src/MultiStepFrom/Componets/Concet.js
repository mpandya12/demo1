import React from 'react'

function Concet() {
  return (
    <div>Concet</div>
  )
}

export default Concet