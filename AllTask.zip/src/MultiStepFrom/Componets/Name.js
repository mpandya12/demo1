import React from 'react'

function Name() {
  return (
    <div>Name</div>
  )
}

export default Name