import React, { useState } from 'react'

function Pagenation() {
    const[limit,setlimit]=useState(5)
    const[currentPage,setCurrentPage]=useState(1)
    

  return (
     <nav>
        <ul>
            <li>
                <al></al>
            </li>
        </ul>
     </nav>
  )
}

export default Pagenation