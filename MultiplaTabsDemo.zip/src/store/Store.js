import {configureStore} from "@reduxjs/toolkit"
import ThunkSlice from "./ThunkSlice"

const store=configureStore({
    reducer:{
            ThunkSlice:ThunkSlice,
            devTools: process.env.NODE_ENV !== 'production' && window.__REDUX_DEVTOOLS_EXTENSION_ && window.__REDUX_DEVTOOLS_EXTENSION_(),
    }
})
 
export default store