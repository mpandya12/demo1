import {createSlice} from "@reduxjs/toolkit"

const initialState={
    thunk:true
}
const ThunkSlice=createSlice({
    name:"ThunkSlice",
    initialState,
    reducers:{
        AddTab:(state,action)=>{
            state.thunk=action.payload
        }
    }
})
export const {AddTab} =ThunkSlice.actions
export default ThunkSlice.reducer

