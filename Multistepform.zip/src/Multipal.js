// MultiStepForm.js
import React, { useState } from 'react';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';

const initialValues = {
  // Define your form fields here
  firstName: '',
  lastName: '',
  email: '',
  password: '',
};

const validationSchema = Yup.object({
  // Define your validation schema here
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
});

const MultiStepForm = () => {
  const [step, setStep] = useState(1);

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <>
            <h2>Step 1: Personal Information</h2>
            <Field type="text" name="firstName" placeholder="First Name" />
            <Field type="text" name="lastName" placeholder="Last Name" />
            <button type="button" onClick={nextStep}>
              Next
            </button>
          </>
        );
      case 2:
        return (
          <>
            <h2>Step 2: Contact Information</h2>
            <Field type="email" name="email" placeholder="Email" />
            <button type="button" onClick={prevStep}>
              Previous
            </button>
            <button type="button" onClick={nextStep}>
              Next
            </button>
          </>
        );
      case 3:
        return (
          <>
            <h2>Step 3: Password</h2>
            <Field type="password" name="password" placeholder="Password" />
            <button type="button" onClick={prevStep}>
              Previous
            </button>
            <button type="submit">Submit</button>
          </>
        );
      default:
        return null;
    }
  };

  const handleSubmit = (values) => {
    console.log('Form Values:', values);
    // ... rest of the code
  }

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      <Form>
        {renderStep()}
      </Form>
    </Formik>
  );
};

export default MultiStepForm;
