import { useEffect, useState } from 'react';

function App() {
  const [tabCount, setTabCount] = useState(1);

  useEffect(() => {
    const storedTabCount = localStorage.getItem('tabCount',tabCount);

    if (storedTabCount) {
   
      setTabCount(parseInt(storedTabCount, 10));
    } else {
    
      localStorage.setItem('tabCount', '1');
    }
  }, []);

  useEffect(() => {
    
    setTabCount((prevCount) => {
      const newCount = prevCount + 1;
    
      localStorage.setItem('tabCount', newCount.toString());
      return newCount;
    });
  }, []);

  useEffect(() => {
    
    return () => {
      setTabCount((prevCount) => {
        const newCount = Math.max(1, prevCount - 1);
        
        localStorage.setItem('tabCount', newCount.toString());
        return newCount;
      });
    };
  }, []);

  return (
    <div className="App">
      <p>Number of Open Tabs: {tabCount}</p>
    </div>
  );
}

export default App;



//
import { useEffect, useState } from 'react';

function App() {
  const MAX_TABS = 3;
  const [openTabs, setOpenTabs] = useState([]);

  useEffect(() => {
    // Set initial tabs when the component mounts
    const storedTabs = JSON.parse(localStorage.getItem('openTabs')) || [];
    setOpenTabs(storedTabs);

    // Increment count when a new tab is opened
    const handleStorage = () => {
      const newTabId = generateTabId();
      const newTabs = [...openTabs, newTabId].slice(-MAX_TABS);
      setOpenTabs(newTabs);
      localStorage.setItem('openTabs', JSON.stringify(newTabs));
    };
    window.addEventListener('storage', handleStorage);

    // Close the oldest tab when a new tab is opened
    if (openTabs.length > MAX_TABS) {
      const oldestTabId = openTabs[0];
      window.close(); // Close the oldest tab
      setOpenTabs((prevTabs) => prevTabs.slice(1)); // Remove the oldest tab from the state
      localStorage.setItem('openTabs', JSON.stringify(openTabs.slice(1))); // Remove the oldest tab from local storage
    }

    return () => {
      window.removeEventListener('storage', handleStorage);
    };
  }, [openTabs]);

  const generateTabId = () => {
    return Date.now().toString() + Math.random().toString(36).substr(2, 5);
  };

  return (
    <div className="App">
      <p>Number of Open Tabs: {openTabs.length}</p>
    </div>
  );
}

export default App;
//
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tab Management</title>
</head>
<body>
  <a href="http://localhost:3000/" target="_blank" onclick="openNewTab(event)">Open Link in New Tab</a>

  <script>
    // Array to store information about opened tabs
    const tabs = [];

    // Maximum number of allowed tabs
    const maxTabs = 3;

    // Function to open a new tab
    function openNewTab(event) {
      // Prevent the default link behavior (opening in a new tab/window)
      event.preventDefault();

      // Check if the number of tabs exceeds the limit
      if (tabs.length >= maxTabs) {
        // Close the oldest tab
        closeOldestTab();
      
      }

      // Open the link in a new tab
      const newTab = window.open(event.target.href, '_blank');

      // Add current timestamp to the tabs array
      tabs.push({
        timestamp: new Date().getTime(),
        tab: newTab
      });

      // Display information about opened tabs (for demonstration purposes)
      console.log('Open Tabs:', tabs);
    }

    // Function to close the oldest tab
    function closeOldestTab() {
      // Find the index of the oldest tab based on the timestamp
      const oldestTabIndex = tabs.findIndex(tabInfo => tabInfo.timestamp === Math.min(...tabs.map(tab => tab.timestamp)));

      // Check if the tab still exists (not manually closed)
      if (oldestTabIndex !== -1) {
        // Close the oldest tab
        const oldestTab = tabs[oldestTabIndex].tab;
        oldestTab.close();

        // Remove the oldest tab from the array
        tabs.splice(oldestTabIndex, 1);
      }
    }
  </script>
</body>
</html>
