import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "../Style.css";

import {
  Container,
  Row,
  Col,
  Button,
  Form as BootstrapForm,
} from "react-bootstrap";
let EMAIL_REGX = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$/;

const Contect = ({ formData, setFormData, handleNext, handlePrev }) => {
 
  return (
    <Container>
      <Row className="justify-content-center">
        <Col md={6}>
          <Formik
            initialValues={formData}
            onSubmit={(values) => {
              setFormData({ ...formData, ...values });
              alert("submit")
              console.log(values);
              console.log(formData);
            }}
          >
            {(formik) => (
              <Form>
                {console.log(formik)}
                <div className="container-fluid bg-dark text-light py-3 ">
                  <header className="text-center"></header>
                </div>
                <div className="container my-2 bg-dark w-100 text-light p-2">
                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Phone</label>
                    <Field
                      type="phone"
                      name="phone"
                      className="form-control"
                    />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Linkdin Id</label>
                    <Field
                      type="text"
                      name="linkdin"
                      className="form-control"
                    />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Github</label>
                    <Field type="text" name="Github" className="form-control" />
                  </BootstrapForm.Group>
                </div>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <Button type="button" variant="primary" onClick={handlePrev}>
                    Perv
                  </Button>
                  <Button type="submit" variant="primary">
                    submit
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default Contect;
