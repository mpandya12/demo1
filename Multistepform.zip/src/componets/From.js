// From.js
import React, { useState } from "react";
import NameDetails from "./NameDetiles";
import Address from "./Address";
import Login from "./Login";
import Contect from "./Contect";
import Button from "react-bootstrap/Button";
import "../App.css";

function From() {
  const [formData, setFormData] = useState({
    fname: "",
    lname: "",
    Username: "",

    email: "",
    password: "",
    address: "",

    city: "",
    state: "",
    pincode: "",

    phone: "",
    linkdin: "",
    Github:""
  });
  const [page, setPage] = useState(0);

  const formTitles = ["UserDetails", "Login", "Address", "Contact"];
  console.log(formData);

  const display = () => {
    switch (page) {
      case 0:
        return <NameDetails formData={formData} setFormData={setFormData} />;
      case 1:
        return <Login />;
      case 2:
      //return <Address />;
      case 3:
        return <Contect />;
      default:
        return null;
    }
  };
  const handleNext = () => {
    console.log("next page");

    setPage((currentPage) => currentPage + 1);
  };

  const handlePrev = () => {
    setPage((currentPage) => currentPage - 1);
  };
  return (
    <>
      <div>
        <h1 style={{ textAlign: "center" }}>Multiple step form</h1>
      </div>
      <div
        style={{
          border: "2px solid black",
          width: "400px",
          margin: "auto",
          marginTop: "80px",
          borderRadius: "10px",
        }}
      >
        <div>
          <h1 style={{ textAlign: "center" }}>{formTitles[page]}</h1>
        </div>
        <div>
          {page === 0 && (
            <NameDetails
              formData={formData}
              setFormData={setFormData}
              handleNext={handleNext}
              handlePrev={handlePrev}
              page={page}
            />
          )}
          {page === 1 && (
            <Login
              formData={formData}
              setFormData={setFormData}
              handleNext={handleNext}
              handlePrev={handlePrev}
            />
          )}

          {page === 2 && (
            <Address
              formData={formData}
              setFormData={setFormData}
              handleNext={handleNext}
              handlePrev={handlePrev}
            />
          )}
          {page === 3 && (
            <Contect
              formData={formData}
              setFormData={setFormData}
              handleNext={handleNext}
              handlePrev={handlePrev}
            />
          )}
        </div>
      </div>
    </>
  );
}

export default From;
