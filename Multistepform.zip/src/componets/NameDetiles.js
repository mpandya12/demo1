
import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { Container, Row, Col, Form as BootstrapForm, Button } from "react-bootstrap";
import "../Style.css";

const NameDetails = ({ formData, setFormData,handleNext,handlePrev,page}) => {
  
  console.log(formData);

  return (
    <Container>
      <Row className="justify-content-center">
        <Col md={6}>
          <Formik 
          // initialValues={{
          //   fname: formData.fname,
          //   lname: formData.lname,
          //   Username:formData.Username
          // }}>
           initialValues={{
               fname: formData.fname,
               lname: formData.lname,
               Username:formData.Username
             }}  
           onSubmit={(values) => {
              setFormData({ ...formData, ...values });
              handleNext(); 
              handlePrev(); 
            }}
            
            >
            {(formik) => (
            
              <Form>
                <div className="container-fluid bg-dark text-light py-3">
                  <header className="text-center"></header>
                </div>
                <div className="container my-2 bg-dark w-100 text-light p-2">
                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>FirstName</label>
                    <Field type="text" name="fname" className="form-control" />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>LastName</label>
                    <Field type="text" name="lname" className="form-control" />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>UserName</label>
                    <Field
                      type="text"
                      name="Username"
                      className="form-control"
                    />
                    <ErrorMessage
                      name="Username"
                      component="div"
                      className="text-danger"
                    />
                  </BootstrapForm.Group>
                </div>
                <div style={{ display: "flex", justifyContent: "center" }}>
                
                  <Button type="button" variant="primary" disabled={page===1}>
                    Perv
                  </Button>
                  <Button type="submit" variant="primary" onClick={handleNext}>
                   Next
                  </Button>

                </div>
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default NameDetails;
