import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "../Style.css";

import {
  Container,
  Row,
  Col,
  Button,
  Form as BootstrapForm,
} from "react-bootstrap";
let EMAIL_REGX = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$/;

const Login = ({ formData, setFormData, handleNext, handlePrev }) => {
  return (
    <Container>
      <Row className="justify-content-center">
        <Col md={6}>
          <Formik
           initialValues={{
            email:formData.email,
            password:formData.password

           }}
           onSubmit={(values) => {
            setFormData({
              ...formData,
              email: values.email,
              password: values.password,
             
            });
          }}
          >
            {(formik) => (
              <Form>
                {console.log(formik)}
                <div className="container-fluid bg-dark text-light py-3 "></div>
                <div className="container my-2 bg-dark w-100 text-light p-2">
                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Email</label>
                    <Field type="text" name="email" className="form-control" />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Password</label>
                    <Field
                      type="password"
                      name="password"
                      className="form-control"
                    />
                    <ErrorMessage
                      name="password"
                      component="div"
                      className="text-danger"
                    />
                  </BootstrapForm.Group>
                </div>
             
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;

//give me css for this from
