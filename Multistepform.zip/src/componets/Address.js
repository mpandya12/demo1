import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import "../Style.css";

import {
  Container,
  Row,
  Col,
  Button,
  Form as BootstrapForm,
} from "react-bootstrap";
let EMAIL_REGX = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$/;

const Address = ({ formData, setFormData, handleNext, handlePrev }) => {
  return (
    <Container>
      <Row className="justify-content-center">
        <Col md={6}>
          <Formik
            initialValues={formData}
            onSubmit={(values) => {
              setFormData({ ...formData, ...values });
              console.log(values);
            }}
          >
            {(formik) => (
              <Form>
                {console.log(formik)}
                <div className="container-fluid bg-dark text-light py-3 ">
                  <header className="text-center"></header>
                </div>
                <div className="container my-2 bg-dark w-100 text-light p-2">
                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>City</label>
                    <Field type="text" name="city" className="form-control" />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>State</label>
                    <Field type="text" name="state" className="form-control" />
                  </BootstrapForm.Group>

                  <BootstrapForm.Group>
                    <label style={{ marginLeft: "20px" }}>Pincode</label>
                    <Field
                      type="number"
                      name="pincode"
                      className="form-control"
                    />
                    <ErrorMessage
                      name="pincode"
                      component="div"
                      className="text-danger"
                    />
                  </BootstrapForm.Group>

                  <div style={{ display: "flex", justifyContent: "center" }}>
                    <Button
                      type="button"
                      variant="primary"
                      onClick={handlePrev}
                    >
                      Perv
                    </Button>
                    <Button
                      type="Button"
                      variant="primary"
                      onClick={handleNext}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </Col>
      </Row>
    </Container>
  );
};

export default Address;


//when i open 3 tabs that time my 1 tab is colse
