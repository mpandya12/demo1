import { useEffect, useState } from 'react';
import From from "./componets/From"

function App() {
  

  
  return (
    <div className="App">
     <From/>
    </div>
  );
}

export default App;
//i do not want to use localStorage i want to use reduxtoolkit to manage my tab counts 